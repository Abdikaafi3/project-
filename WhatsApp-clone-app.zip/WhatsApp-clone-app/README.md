
- [Youtube](https://youtu.be/f-NUpdJ1rEE)
- [LinkedIn](https://www.linkedin.com/in/axiftaj/)
- [Facebook Group](https://www.facebook.com/aaxiftaj)
- - [Buy me coffe](https://www.buymeacoffee.com/axiftaj)


![akhri ](https://user-images.githubusercontent.com/47206155/159860726-2d0e0f30-a5b4-43d9-b813-7df3e25c87df.png)


![Simulator Screen Recording - iPhone X - 2022-03-23 at 21 13 24](https://user-images.githubusercontent.com/47206155/159761478-e372e2cd-ba0d-4a2e-85d2-93492bba2cca.gif)
