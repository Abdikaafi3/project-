class CallItemModel {

  String name;
  String dateTime;
  String image;

  CallItemModel(this.name, this.dateTime , this.image);

}