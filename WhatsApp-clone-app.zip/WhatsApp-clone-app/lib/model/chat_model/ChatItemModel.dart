class ChatItemModel {

  String name;
  String mostRecentMessage;
  String messageDate;
  String image;
  
  ChatItemModel(this.name, this.mostRecentMessage, this.messageDate , this.image);

}