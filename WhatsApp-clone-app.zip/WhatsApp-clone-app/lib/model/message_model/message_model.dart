class MessageItemModel {

  String name;
  String mostRecentMessage;
  String messageDate;
  String type;

  MessageItemModel(this.name, this.mostRecentMessage, this.messageDate, this.type);

}