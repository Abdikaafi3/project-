class StatusItemModel {

  String name;
  String dateTime;
  String image;

  StatusItemModel(this.name, this.dateTime , this.image );

}