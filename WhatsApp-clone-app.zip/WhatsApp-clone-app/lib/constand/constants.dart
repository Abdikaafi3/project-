

const  Bold = 'Bold' ;
const  Regular = 'Regular' ;
